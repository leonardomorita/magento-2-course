<?php

namespace TestVendorName\TestModuleName\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use TestVendorName\TestModuleName\SomeFolderName\SomeClassInterface;

class Index extends Action
{
    /**
     * @var SomeClassInterface
     */
    private $someClass;

    public function __construct(Context $context, SomeClassInterface $someClass)
    {
        parent::__construct($context);
        $this->someClass = $someClass;
    }

    public function execute()
    {
        // $someObject = new \TestVendorName\TestModuleName\SomeFolderName\SomeClassName();
        
        echo "Hello World Test! <br>";
        echo get_class($this->someClass);
        // print_r($someObject->someMethod());
    }
}
