<?php

namespace TestVendorName\TestModuleName\SomeFolderName;

class SomeClassName implements SomeClassInterface
{
    public function someMethod()
    {
        return ['some value'];
    }
}