<?php

namespace TestVendorName\TestModuleName\SomeFolderName;

interface SomeClassInterface
{
    public function someMethod();
}